package com.kbtu.dukenapp.presentation.features.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import coil.compose.rememberAsyncImagePainter
import com.kbtu.dukenapp.domain.model.characters.ProductItem
import com.kbtu.dukenapp.presentation.state.ComponentRectangleLineLong
import com.kbtu.dukenapp.presentation.state.ManagementResourceUiState
import com.kbtu.dukenapp.ui.theme.Paddings
import com.kbtu.dukenapp.utils.Screen
import com.kbtu.dukenapp.utils.extension.noRippleClickable
import org.koin.androidx.compose.koinViewModel

@Composable
fun HomeScreen(
    navController: NavHostController,
    viewModel: HomeViewModel = koinViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = Paddings.medium)
    ) {
        // TopAppBar with logout button
        item {
            HomeTopAppBar(navController)
        }

        // Display products or loading view
        item {
            ManagementResourceUiState(
                modifier = Modifier.padding(bottom = Paddings.medium),
                resourceUiState = state.productList,
                successView = {
                    Column {
                        it.forEach { product ->
                            ProductItem(
                                productItem = product,
                                onClick = {
                                    // Handle product item click
                                }
                            )
                        }
                    }
                },
                loadingView = {
                    Column {
                        for (i in 1..5) {
                            ItemOnLoading()
                        }
                    }
                },
                onCheckAgain = {},
                onTryAgain = {},
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeTopAppBar(navController: NavHostController) {
    TopAppBar(
        title = {
            Text(
                text = "Home",
                style = MaterialTheme.typography.bodyLarge.copy(fontSize = 20.sp)
            )
        },
        actions = {
            IconButton(onClick = {
                // Navigate to SignIn screen on logout
                navController.navigate(Screen.SignIn.route)
            }) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                    contentDescription = "Logout"
                )
            }
        },
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = Paddings.small)
    )
}

@Composable
fun ProductItem(
    modifier: Modifier = Modifier,
    productItem: ProductItem,
    onClick: (ProductItem) -> Unit
) {
    // Состояние для показа диалога
    var showDialog by remember { mutableStateOf(false) }

    // Диалог для отображения подробной информации о товаре
    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = {
                Text(
                    text = productItem.name,
                    style = MaterialTheme.typography.titleMedium
                )
            },
            text = {
                Column(
                    horizontalAlignment = Alignment.Start,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Большая картинка товара
                    Image(
                        painter = rememberAsyncImagePainter(productItem.imageUrl),
                        contentDescription = "Product Image",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(250.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .border(1.dp, Color.Gray, RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Полное описание товара
                    Text(
                        text = productItem.description,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Цена товара
                    Text(
                        text = "\$${productItem.price}",
                        style = MaterialTheme.typography.bodyLarge.copy(color = Color(0xFF006400)),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showDialog = false }) {
                    Text("Close")
                }
            }
        )
    }

    // Контейнер для товара с изображением, названием, описанием и ценой
    Box(
        modifier = modifier
            .padding(top = Paddings.xxSmall, bottom = Paddings.small6dp)
            .shadow(Paddings.extraSmall, shape = RoundedCornerShape(Paddings.small))
            .background(Color.White, RoundedCornerShape(Paddings.small))
            .fillMaxWidth()
            .wrapContentHeight()
            .noRippleClickable { showDialog = true }  // Показать диалог при клике
    ) {
        Row(
            modifier = modifier
                .fillMaxWidth()
                .padding(Paddings.medium),
            horizontalArrangement = Arrangement.spacedBy(Paddings.medium),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Фотография товара
            Image(
                painter = rememberAsyncImagePainter(productItem.imageUrl),
                contentDescription = "Product Image",
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(Paddings.small))
                    .border(1.dp, Color.Gray, RoundedCornerShape(Paddings.small)),
                contentScale = ContentScale.Crop
            )

            // Информация о товаре
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .weight(1f)
            ) {
                Text(
                    text = productItem.name,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = productItem.description,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Цена товара
            Text(
                text = "\$${productItem.price}",
                style = MaterialTheme.typography.bodyLarge.copy(color = Color(0xFF006400)), // Темно-зеленый цвет
                modifier = Modifier.align(Alignment.CenterVertically)
            )
        }
    }
}

@Composable
private fun ItemOnLoading(
    modifier: Modifier = Modifier,
) {
    Box(
        modifier = modifier
            .padding(top = Paddings.xxSmall, bottom = Paddings.small6dp)
            .shadow(Paddings.extraSmall, shape = RoundedCornerShape(Paddings.small))
            .background(Color.White, RoundedCornerShape(Paddings.small))
            .fillMaxWidth()
            .wrapContentHeight()
    ) {
        Row(
            modifier = modifier
                .fillMaxWidth()
                .padding(Paddings.medium),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ComponentRectangleLineLong()
        }
    }
}


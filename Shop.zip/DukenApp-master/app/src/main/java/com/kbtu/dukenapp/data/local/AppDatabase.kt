package com.kbtu.dukenapp.data.local
import com.kbtu.dukenapp.data.model.user.UserDBModel

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [UserDBModel::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun onlineStoreDao(): AuthorizationDao
}
package com.kbtu.dukenapp.presentation.features.sign_up

import android.util.Log
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.viewModelScope
import com.kbtu.dukenapp.domain.model.User
import com.kbtu.dukenapp.domain.repository.AuthorizationRepository
import com.kbtu.dukenapp.presentation.model.ResourceUiState
import com.kbtu.dukenapp.presentation.model.TextFieldUiState
import com.kbtu.dukenapp.presentation.model.ValidationResult
import com.kbtu.dukenapp.presentation.mvi.BaseViewModel
import kotlinx.coroutines.launch

class SignUpViewModel(
    private val repository: AuthorizationRepository
) : BaseViewModel<SigUpContract.State, SigUpContract.Event, SigUpContract.Effect>() {

    override fun createInitialState(): SigUpContract.State =
        SigUpContract.State(
            name = TextFieldUiState(
                input = mutableStateOf(""),
                validationResult = mutableStateOf(ValidationResult(successful = false)),
                onFieldChanged = {
                    updateButtonState()
                }
            ),
            email = TextFieldUiState(
                input = mutableStateOf(""),
                validationResult = mutableStateOf(ValidationResult(successful = false)),
                onFieldChanged = {
                    updateButtonState()
                }
            ),
            password = TextFieldUiState(
                input = mutableStateOf(""),
                validationResult = mutableStateOf(ValidationResult(successful = false)),
                onFieldChanged = {
                    updateButtonState()
                }
            ),
            signUpState = ResourceUiState.Idle
        )

    // Обновляем состояние кнопки и валидацию
    private fun updateButtonState() {
        with(currentState) {
            val isNameValid = state.name.input.value.isNotEmpty()
            val isEmailValid = validateEmail(state.email.input.value)
            val isPasswordValid = validatePassword(state.password.input.value)

            setState {
                copy(
                    name = name.copy(validationResult = mutableStateOf(ValidationResult(isNameValid))),
                    email = email.copy(validationResult = mutableStateOf(ValidationResult(isEmailValid))),
                    password = password.copy(validationResult = mutableStateOf(ValidationResult(isPasswordValid))),
                    isButtonAvailable = isNameValid && isEmailValid && isPasswordValid
                )
            }
        }
    }

    private fun validateEmail(email: String): Boolean {
        val emailPattern = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$"
        return email.matches(emailPattern.toRegex())
    }

    private fun validatePassword(password: String): Boolean {
        val passwordPattern = "^(?=.*[0-9])(?=.*[a-zA-Z]).{8,}$"
        return password.matches(passwordPattern.toRegex())
    }

    override fun handleEvent(event: SigUpContract.Event) {
        when (event) {
            SigUpContract.Event.OnSignUpClicked -> registerUser()
        }
    }

    private fun registerUser() {
        viewModelScope.launch {
            try {
                setState { copy(signUpState = ResourceUiState.Loading) }
                setEffect { SigUpContract.Effect.OnLoading }

                // Искусственная задержка для демонстрации
                kotlinx.coroutines.delay(2000)

                repository.createUser(
                    User(
                        id = 0,
                        name = state.name.input.value,
                        email = state.email.input.value,
                        password = state.password.input.value
                    )
                )

                setState { copy(signUpState = ResourceUiState.Success(Unit)) }
                setEffect { SigUpContract.Effect.OnUserRegistered }
            } catch (e: Exception) {
                Log.e("SignUpViewModel", "Error during registration: ${e.message}")
                setState { copy(signUpState = ResourceUiState.Error(e.message)) }
                setEffect { SigUpContract.Effect.OnUserAlreadyExists }
            }
        }
    }
}

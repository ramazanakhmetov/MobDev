package com.kbtu.dukenapp.utils

object Constants {
    const val LOCATION_DB = "location"
    const val USERS = "users"
    const val BASE_URL = "https://run.mocky.io/v3/"
    const val API_KEY = "e896f665e1b1f434c1ee2fbedac07c19"
}
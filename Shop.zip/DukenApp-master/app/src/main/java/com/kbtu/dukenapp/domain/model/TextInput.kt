package com.kbtu.dukenapp.domain.model

enum class TextInput {
    BASE,
    EMAIL_ADDRESS,
    PASSWORD,
    CONFIRM_PASSWORD,
    FIRST_NAME,
    LAST_NAME,
}
package com.kbtu.dukenapp.presentation.features.sign_in

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import coil.compose.AsyncImage
import com.kbtu.dukenapp.presentation.common.CustomEmailTextField
import com.kbtu.dukenapp.presentation.common.CustomPasswordTextField
import com.kbtu.dukenapp.presentation.common.LoaderPopup
import com.kbtu.dukenapp.presentation.model.TextFieldUiState
import com.kbtu.dukenapp.ui.theme.Paddings
import com.kbtu.dukenapp.utils.Screen
import com.kbtu.dukenapp.utils.extension.noRippleClickable
import org.koin.androidx.compose.koinViewModel

@Composable
fun SignInScreen(
    navController: NavHostController,
    viewModel: SigInViewModel = koinViewModel(),
    logoUrl: String = "https://assets.turbologo.ru/blog/ru/2017/09/18170925/eshop-logo.png" // Пример URL для логотипа
) {
    val uiState by viewModel.uiState.collectAsState()
    val loadingView = remember { mutableStateOf(false) }
    val context = LocalContext.current

    LoaderPopup(loadingPopup = loadingView)

    LaunchedEffect(Unit) {
        viewModel.effect.collect { effect ->
            when (effect) {
                SigInContract.Effect.OnUserFetched -> {
                    loadingView.value = false
                    navController.navigate(Screen.Home.route)
                }
                SigInContract.Effect.OnUserDoNotExist -> {
                    loadingView.value = false
                    Toast.makeText(context, "User does not exist", Toast.LENGTH_SHORT).show()
                }
                SigInContract.Effect.OnLoading -> {
                    loadingView.value = true
                }
            }
        }
    }

    // Основной экран с логотипом и полями для ввода
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = Paddings.medium)
            .verticalScroll(rememberScrollState()) // Добавление прокрутки
            .imePadding(), // Добавление отступа для клавиатуры
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Место для логотипа
        AsyncImage(
            model = logoUrl,
            contentDescription = "App Logo",
            modifier = Modifier
                .size(120.dp)
                .padding(bottom = 32.dp)
        )

        // Заголовок приложения
        Text(
            text = "Welcome!",
            style = MaterialTheme.typography.headlineLarge, // Используем headlineLarge для заголовка
            color = Color(0xFF333333),
            modifier = Modifier.padding(bottom = 32.dp)
        )

        // Поля ввода (Email и Password)
        LoginFields(
            email = uiState.email,
            password = uiState.password
        )

        Spacer(modifier = Modifier.height(Paddings.standard12dp))

        // Кнопка перехода на экран регистрации
        SignUpButton(
            onSignUpClicked = { navController.navigate(Screen.SignUp.route) }
        )

        Spacer(modifier = Modifier.height(Paddings.extraLarge))

        // Кнопка входа
        LoginButton(
            onLoginClicked = { viewModel.setEvent(SigInContract.Event.OnLoginClicked) },
            enabled = uiState.isButtonAvailable
        )
    }
}

@Composable
fun SignUpButton(onSignUpClicked: () -> Unit) {
    Text(
        text = "Sign up",
        style = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.primary),
        modifier = Modifier
            .padding(vertical = 16.dp)
            .noRippleClickable { onSignUpClicked() }
    )
}

@Composable
fun LoginButton(enabled: Boolean, onLoginClicked: () -> Unit) {
    Text(
        text = "Login",
        style = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.primary),
        modifier = Modifier
            .padding(vertical = 16.dp)
            .noRippleClickable { onLoginClicked() }
            .then(
                if (!enabled) {
                    Modifier.alpha(0.5f) // Добавляем полупрозрачность, если кнопка неактивна
                } else {
                    Modifier
                }
            )
    )
}

@Composable
private fun LoginFields(email: TextFieldUiState, password: TextFieldUiState) {
    EmailField(email = email)
    Spacer(modifier = Modifier.height(Paddings.extraLarge))
    PasswordField(password = password)
}

@Composable
private fun PasswordField(password: TextFieldUiState) {
    Text(text = "Password", style = MaterialTheme.typography.bodyMedium) // Используем bodyMedium для текста
    Spacer(modifier = Modifier.height(Paddings.small))
    CustomPasswordTextField(password)
}

@Composable
private fun EmailField(email: TextFieldUiState) {
    Text(text = "Email", style = MaterialTheme.typography.bodyMedium) // Используем bodyMedium для текста
    Spacer(modifier = Modifier.height(Paddings.small))
    CustomEmailTextField(email)
}

@Preview(showBackground = true)
@Composable
fun PreviewSignInScreen() {
    // Корректное создание NavHostController для Preview
    SignInScreen(
        navController = NavHostController(LocalContext.current),
        logoUrl = "https://assets.turbologo.ru/blog/ru/2017/09/18170925/eshop-logo.png"
    )
}

package com.kbtu.dukenapp.data.api

import com.kbtu.dukenapp.data.model.products.ProductsApiModel
import retrofit2.http.GET

interface OnlineStoreService {

    @GET("fff6927f-fdce-433a-8872-e8c1c154a404")
    suspend fun getProductList(): ProductsApiModel
}
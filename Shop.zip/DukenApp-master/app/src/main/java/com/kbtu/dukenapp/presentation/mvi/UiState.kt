package com.kbtu.dukenapp.presentation.mvi

interface UiState

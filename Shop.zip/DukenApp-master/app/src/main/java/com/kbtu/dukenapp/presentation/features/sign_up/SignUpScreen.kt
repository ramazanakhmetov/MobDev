package com.kbtu.dukenapp.presentation.features.sign_up

import android.widget.Toast
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.kbtu.dukenapp.presentation.common.CustomYellowButton
import com.kbtu.dukenapp.presentation.common.LoaderPopup
import com.kbtu.dukenapp.presentation.model.TextFieldUiState
import com.kbtu.dukenapp.ui.theme.Paddings
import com.kbtu.dukenapp.utils.Screen
import org.koin.androidx.compose.koinViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SignUpScreen(
    navController: NavHostController,
    viewModel: SignUpViewModel = koinViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val loadingView = remember { mutableStateOf(false) }
    val context = LocalContext.current

    LoaderPopup(loadingPopup = loadingView)

    LaunchedEffect(Unit) {
        viewModel.effect.collect { effect ->
            when (effect) {
                SigUpContract.Effect.OnUserRegistered -> {
                    loadingView.value = false
                    navController.navigate(Screen.Home.route)
                }
                SigUpContract.Effect.OnUserAlreadyExists -> {
                    loadingView.value = false
                    Toast.makeText(context, "User already exists", Toast.LENGTH_SHORT).show()
                }
                SigUpContract.Effect.OnLoading -> {
                    loadingView.value = true
                }
            }
        }
    }

    // Применяем imePadding() к Column для добавления отступа снизу, когда клавиатура открыта
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = Paddings.medium)
    ) {
        // Добавление TopAppBar с кнопкой "Назад"
        TopAppBar(
            title = {
                Text(
                    "Sign Up",
                    style = MaterialTheme.typography.titleLarge.copy(fontSize = 18.sp, fontWeight = FontWeight.Bold) // Сделали стиль заголовка ярким
                )
            },
            navigationIcon = {
                IconButton(onClick = {
                    navController.popBackStack()
                }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.Black) // Сделали иконку черной для контраста
                }
            },
            modifier = Modifier.height(56.dp), // Стандартная высота TopAppBar
            colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White) // Белый фон для заголовка
        )

        Spacer(modifier = Modifier.height(Paddings.extraLarge))

        SignUpContent(
            state = uiState,
            onSignUpClicked = { viewModel.setEvent(SigUpContract.Event.OnSignUpClicked) }
        )
    }
}

@Composable
private fun SignUpContent(
    modifier: Modifier = Modifier,
    state: SigUpContract.State,
    onSignUpClicked: () -> Unit
) {
    val lazyListState = rememberLazyListState()

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            state = lazyListState,
            modifier = Modifier
                .fillMaxSize()
                .padding(end = 16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(Paddings.extraLarge))

                // Стильные текстовые поля и кнопки
                SignUpFields(
                    name = state.name,
                    email = state.email,
                    password = state.password
                )

                Spacer(modifier = Modifier.height(Paddings.extraLarge))

                SignUpButton(
                    enabled = state.isButtonAvailable,
                    onSignUpClicked = onSignUpClicked
                )
            }
        }
    }
}

@Composable
private fun SignUpButton(enabled: Boolean, onSignUpClicked: () -> Unit) {
    CustomYellowButton(
        onClick = onSignUpClicked,
        enabled = enabled,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 16.dp),
        content = {
            Text(
                text = "Sign Up",
                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold) // Replaced `button` with `bodyLarge`
            )
        }
    )
}

@Composable
private fun SignUpFields(
    name: TextFieldUiState,
    email: TextFieldUiState,
    password: TextFieldUiState
) {
    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        InputFieldWithError(
            label = "Name",
            textFieldState = name
        )

        Spacer(modifier = Modifier.height(16.dp))

        InputFieldWithError(
            label = "Email",
            textFieldState = email
        )

        Spacer(modifier = Modifier.height(16.dp))

        InputFieldWithError(
            label = "Password",
            textFieldState = password
        )
    }
}

@Composable
private fun InputFieldWithError(
    label: String,
    textFieldState: TextFieldUiState
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            modifier = Modifier.padding(start = 8.dp)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, if (textFieldState.validationResult.value.successful) Color.Green else Color.Gray, MaterialTheme.shapes.small)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                BasicTextField(
                    value = textFieldState.input.value,
                    onValueChange = { newText ->
                        textFieldState.input.value = newText
                        textFieldState.onFieldChanged()
                    },
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = Color.Black),
                    decorationBox = { innerTextField ->
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                        ) {
                            if (textFieldState.input.value.isEmpty()) {
                                Text(
                                    text = label,
                                    color = Color.Gray,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            }
                            innerTextField()
                        }
                    }
                )

                // Галочка, если валидация успешна
                if (textFieldState.validationResult.value.successful) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Valid",
                        tint = Color.Green
                    )
                }
            }
        }

        // Сообщение об ошибке
        if (!textFieldState.validationResult.value.successful) {
            Text(
                text = AnnotatedString((textFieldState.validationResult.value.errorMessage ?: "").toString()),
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(start = 8.dp)
            )
        }
    }
}

